package main

import "./jsonurlv2"

func main() {
	//readurl.ExDecodeMine("http://samples.openweathermap.org/data/2.5/weather?zip=94040%2Cus&appid=b1b15e88fa797225412429c1c50c122a1")
	jsonurl.JsonUrl()
}
